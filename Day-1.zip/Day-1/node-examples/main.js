var cal = require("./cal.js");
var payroll = require("./payroll");

console.log("Modules are loaded/imported successfully!!!!")

console.log(cal.title +" "+ cal.version);

cal.doSum(10,2);
cal.doDiff(10,2);
cal.doMultiplyA(10,2);
cal.doMultiplyB(10,2);
cal.doMultiplyC(10,2);

payroll.calHra(60000.00);
payroll.calDa(60000.00);





