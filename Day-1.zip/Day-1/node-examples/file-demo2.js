var fs = require("fs"); 
console.log("Modules are loaded/imported successfully!!!!")

var path = "./cricket.txt";

//Error first callbacks
function handleResult(err,content) {
	console.log("File reading done!!!!!");
	if(err) {
		console.log("File processing Error ============>  "+ err.message);
		return;
	}
	console.log("File Content ============>  "+ content);
	//20 LOC
	console.log("File Content ============>  "+ content.toString().toUpperCase());
}

console.log("Check Point 1 ==========>");

//NoN Blocking function call
//Asynchronous function
fs.readFile(path,handleResult);

console.log("Check Point 2 ==========>");
//20 LOC ---> do not write dependent business logic here, move it to callback
console.log("Finish Line  ==========>");



