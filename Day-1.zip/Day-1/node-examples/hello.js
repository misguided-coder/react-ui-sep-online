var i = 1000;
console.log(i);

for(var idx=0;idx<10;idx++) {
	console.log(idx);
}

function hello() {
	console.log("Hello All");
}

hello();


var date = new Date();

console.log(date);
