var fs = require("fs"); 

var stream1 = new fs.ReadStream('./cricket.txt');
var stream2 = new fs.ReadStream('./holiday.txt','utf-8');

stream.addListener('open',function(){
	console.log('File opened successfully!!!!!')
});

stream.on('open',function(){
	console.log('File opened successfully!!!!!')
});

stream.on('data',function(chunk){
	console.log('Data is ready!!!!!');
	//2 minutes time taken
	if(Buffer.isBuffer(chunk)){
		console.log(chunk.toString());
	} else {
		console.log(chunk);
	}
});

stream.on('end',function(){
	console.log('File reading is finished!!!!!');
});


stream.on('close',function(){
	console.log('File is closed successfully!!!!!');
});


stream.on('error',function(err){
	console.log('Error in processing File =================> '+err.message);
});

