//synchronous function
//blocking function
function hello() {
	console.log("Inside hello()");
	//took 10 minutes to execute
	//last line of code	
}

function hi() {
	console.log("Inside hi()");
	//took 2 minutes to execute	
	//last line of code	
}

function bye() {
	console.log("Inside bye()");
	//took 4 minutes to execute	
}

hello();
hi();
bye();
