var fs = require("fs"); 
console.log("Modules are loaded/imported successfully!!!!")

var pathA = "./cricket.txt";
var pathB = "./holiday.txt";


//Error first callbacks
function handleResultB(err,content) {
	console.log("File B reading done!!!!!");
	if(err) {
		console.log("File processing Error ============>  "+ err.message);
		return;
	}
	console.log("File Content ============>  "+ content);
	//20 LOC
	console.log("File Content ============>  "+ content.toString().toUpperCase());
}


//Error first callbacks
function handleResultA(err,content) {
	console.log("File A reading done!!!!!");
	if(err) {
		console.log("File processing Error ============>  "+ err.message);
		return;
	}
	console.log("File Content ============>  "+ content);
	//20 LOC
	console.log("File Content ============>  "+ content.toString().toUpperCase());
	fs.readFile(pathB,handleResultB);
}

console.log("Check Point 1 ==========>");

//NoN Blocking function call
//Asynchronous function
fs.readFile(pathA,handleResultA);

console.log("Check Point 2 ==========>");
//20 LOC ---> do not write dependent business logic here, move it to callback
console.log("Finish Line  ==========>");



