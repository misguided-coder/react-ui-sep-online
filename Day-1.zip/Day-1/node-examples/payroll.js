function hra(basic) {
	console.log("HRA : "+(basic * 0.40));
}

function da(basic) {
	console.log("DA : "+(basic * 0.08));
}

exports.calHra = hra;
exports.calDa = da;
