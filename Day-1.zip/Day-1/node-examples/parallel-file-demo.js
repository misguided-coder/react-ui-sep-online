var fs = require("fs"); 

function handleFileAContent(err,content) {
	console.log("File A reading done!!!!!");
	console.log("File A Content ============>  "+ content);
}

function handleFileBContent(err,content) {
	console.log("File B reading done!!!!!");
	console.log("File B Content ============>  "+ content);
}

console.log("Check Point 1 ==========>");

fs.readFile('./cricket.txt',handleFileAContent);

console.log("Check Point 2 ==========>");

fs.readFile('./holiday.txt',handleFileBContent);

console.log("Check Point 3 ==========>");

console.log("Finish Line  ==========>");



