function sum(a,b) {
	console.log("SUM : "+(a+b));
}

function diff(a,b) {
	console.log("DIFF : "+(a-b));
}


function multiply (a,b) {
	console.log("Multiply : "+(a*b));
};


/*function (a,b) {
	console.log("Multiply : "+(a*b));
};*/


exports.title = "Simple Math Calculator";
exports.version = "2.0.0";

exports.doSum = sum;
exports.doDiff = diff;
exports.doMultiplyA = multiply;

exports.doMultiplyB = function (a,b) {
	console.log("Multiply : "+(a*b));
};

exports.doMultiplyC = (a,b) => {
	console.log("Multiply : "+(a*b));
};


