var os = require("os"); 
var fs = require("fs"); 
console.log("Modules are loaded/imported successfully!!!!")

var path = "C:/REACT-IBM/Day-1/node-examples/cricket.txt";

var content = fs.readFileSync(path);
console.log("File Content ============>  "+ content);

console.log(os.platform());
console.log(os.arch());
console.log(os.cpus());
console.log(os.uptime());
console.log(os.totalmem());


