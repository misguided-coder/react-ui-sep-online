//synchronous function
//blocking function
function hello() {
	console.log("Inside hello() ======> START");
	//took 10 minutes to execute
	//last line of code
	hi();	
	console.log("Inside hello()  ======> END");
}

//synchronous function
//blocking function
function hi() {
	console.log("Inside hi() ======> START");
	//took 2 minutes to execute	
	//last line of code	
	bye();
	console.log("Inside hi()  ======> END");
}

//synchronous function
//blocking function
function bye() {
	console.log("Inside bye() ======> START");
	//took 4 minutes to execute	
	console.log("Inside bye()  ======> END");
}

hello();
console.log("Run final logic here...");
