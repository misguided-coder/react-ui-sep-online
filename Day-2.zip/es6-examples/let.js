const MARKS = 500;
console.log(MARKS);
MARKS = 1000;
console.log(MARKS);


function doWork() {
	if(true) {
		var i = 1000; //no block level scope
		let j = 2000; //block level scope
		console.log(i);
		console.log(j);
	}
	console.log(i);
	//console.log(j);  // will not work
}

doWork();


for(var counter = 1; counter <= 20; counter++) {
	//console.log(counter);
}

console.log("=============================");
console.log(counter);

