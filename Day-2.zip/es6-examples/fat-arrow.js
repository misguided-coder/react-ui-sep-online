function hello() {
	console.log("Hello All");
}

var hi = function () {
	console.log("Hi All");
}

var bye = () => {
	console.log("Bye All");
}

hello();
hi();
bye();


/*var greet = (name) => {
	console.log("GM "+name);
}*/

//var greet = (name) => console.log("GM "+name);

var greet = name => console.log("GM "+name);

/*var sum = (a,b) => {
	return a+b;
}*/

var sum = (a,b) => a+b; 



greet('Raj');

var rs = sum(120,2);
console.log(rs);
