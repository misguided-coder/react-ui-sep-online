class Hotel {
	
	constructor(){
		console.log("Inside Hotel constructor()!!!!");
		this.name = 'Taj Palace';	
		this.rooms = 210;	
	}

	bookRoom(howMany) {
		this.rooms = this.rooms - howMany;
		console.log(howMany +" rooms booked!!!!");
	}
}


class LuxuryHotel extends Hotel {
	constructor(){
		super();
		console.log("Inside LuxuryHotel constructor()!!!!");
		this.roomTraffic = 60000.00;
	}
	
}


var hotel = new Hotel();
var luxuryHotel = new LuxuryHotel();

console.log(hotel.name);
console.log(hotel.rooms);
hotel.rooms = 340;
console.log(hotel.rooms);

hotel.bookRoom(3);


console.log(luxuryHotel.name);
luxuryHotel.bookRoom(6);



