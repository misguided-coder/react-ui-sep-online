var name = 'Rohan';
var city = 'Pune';

console.log("Hello Mr. "+name+", We know you live in "+city+" city");
console.log('Hello Mr. '+name+', We know you live in '+city+' city');

console.log("Hello Mr. ${name}, We know you live in ${city} city");
console.log('Hello Mr. ${name}, We know you live in ${city} city');
console.log(`Hello Mr. ${name}, We know you live in ${city} city`);




