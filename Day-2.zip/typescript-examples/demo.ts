var rooms:number = "asdjksdsahkdgsa";
console.log(rooms);


