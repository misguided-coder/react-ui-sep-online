var person = ['Jaggu',21,'980000000','jaggi@yahoo.com','MG Road'];

var name = person[0];
var age = person[1];
var phone = person[2];

console.log(`Name : ${name}`);
console.log(`Age : ${age}`);
console.log(`Phone : ${phone}`);
console.log("=============================");

var [name1,age1,phone1] = person;

console.log(`Name : ${name1}`);
console.log(`Age : ${age1}`);
console.log(`Phone : ${phone1}`);
console.log("=============================");

var car = {vin:100,model:'Q7',make:'Audi',price:80000.00};

/*var vin = car.vin;
var model = car.model;
var make = car.make;
var price = car.price;

console.log(vin);
console.log(model);
console.log(make);
console.log(price);
console.log("=============================");
*/


var {vin,model,make,price} = car;

console.log(vin);
console.log(model);
console.log(make);
console.log(price);
console.log("=============================");






 

