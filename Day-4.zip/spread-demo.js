function display(name,age,phone) {
	console.log(`Name : ${name}`);
	console.log(`Age : ${age}`);
	console.log(`Phone : ${phone}`);
	console.log("=============================");
}

display('Raj',23,'9812020202');

var array = ['Jaggu',21,'980000000'];

display(array[0],array[1],array[2]);

display(...array);

//Copy memory address
//var array2 =  array;

//Copy array elements
//var array2 =  [array[0],array[1],array[2]];
var array2 =  [...array,'A','B','C'];

array2.push('jaggu@yahoo.com');

console.log(array2);
console.log(array);



