var numbers = [24,34,12,76,89,12,54,67,98];

var resultArray = [];

for(var idx=0;idx<numbers.length;idx++) {
	resultArray.push(numbers[idx] * 2); 
}

console.log(numbers);
console.log(resultArray);

var rs = numbers.map(function(val,idx){ return val * 2 }); 

console.log(rs);


